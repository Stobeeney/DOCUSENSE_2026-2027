from logging.config import fileConfig

from sqlalchemy import create_engine, pool

from alembic import context
from app import models  # noqa: F401  (registers all tables on Base.metadata)
from app.config import get_settings
from app.db import Base, engine_options, normalize_url

config = context.config
# Not stored in the ini config: ConfigParser would choke on the '%' of a URL-encoded password.
DATABASE_URL = normalize_url(get_settings().database_url)

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

target_metadata = Base.metadata


def run_migrations_offline() -> None:
    context.configure(
        url=DATABASE_URL,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    # Same connect options as the app (no server-side prepared statements, so a Supabase
    # pooler URL works too), but no pool: one connection for the run.
    connect_args = engine_options(DATABASE_URL).get("connect_args", {})
    connectable = create_engine(DATABASE_URL, poolclass=pool.NullPool, connect_args=connect_args)
    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
